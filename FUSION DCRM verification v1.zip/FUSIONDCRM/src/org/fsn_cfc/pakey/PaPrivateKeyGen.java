package org.fsn_cfc.pakey;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Random;


public class PaPrivateKeyGen {
   
	
	public static PaPrivateKey PaPrivateKeyGen(int s, long seed) {
		
		if (s<=0) {
			throw new IllegalArgumentException("Number of bits set is less than 0");
		}
		
		BigInteger minprm=null;
		BigInteger maxprm=null;
		BigInteger phin=null;
		BigInteger p;
		BigInteger q;
		BigInteger d;
		BigInteger n;
		SecureRandom rnd;
		
		boolean ok=false;
		
		
		rnd= new SecureRandom(BigInteger.valueOf(seed).toByteArray());
		
		do {
			p = PaPrivateKeyGen.getPrime(s, rnd);
			q = PaPrivateKeyGen.getPrime(s, rnd); 
			minprm = q.min(p);
			maxprm = q.max(p);
			
			//Make the smallest prime p, maximum q
			p = minprm;
			q = maxprm;
			
			// Now verify that p-1 does not divide q
			if((q.mod(p.subtract(BigInteger.ONE))).compareTo(BigInteger.ZERO)!=0) {
				ok=true;
			}
			
		} while(!ok);
		
		//n=p*q
		n=p.multiply(q);
		  		
		//phi(n)=(p-1)*(q-1);
		phin=(p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
		  
		//Now we can calculate the Carmichael's function for n
		//i.e., lcm(p-1,q-1)
		//Note that phi(n)=gcd(p-1,q-1)*lcm(p-1,q-1)
		d=phin.divide((p.subtract(BigInteger.ONE)).gcd(q.subtract(BigInteger.ONE)));
		
		return new PaPrivateKey(n, d, seed);
	}

	
	
	public static BigInteger getPrime(int length, Random random) {
		return BigInteger.probablePrime(length, random);
	}
	
}
