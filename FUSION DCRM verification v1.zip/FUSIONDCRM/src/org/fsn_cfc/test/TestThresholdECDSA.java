package org.fsn_cfc.test;

import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;
import org.bouncycastle.math.ec.ECPoint;
import org.fsn_cfc.fusiondcrm.FusionDCRM;
import org.fsn_cfc.util.ECDSASignature;
import org.fsn_cfc.util.OtherUtil;
import org.fsn_cfc.util.User;

public class TestThresholdECDSA {
	
	public static void main(String[] args) {
		
		Scanner sinput = new Scanner(System.in);  
		
        System.out.print("please input the message to be signed:");  
        String message = sinput.nextLine();
        
        System.out.print("please input the number of LILO supreme nodes:");  
        int userCount = sinput.nextInt();
        
        //key generate
        List<User> userList = FusionDCRM.keyGenerate(userCount);
        
        //Encrypted Private Key
        BigInteger encX = FusionDCRM.calculateEncPrivateKey(userList);
        
        //public key
        ECPoint pk = FusionDCRM.calculatePubKey(userList);
        
        //signature generate
        ECDSASignature signature = FusionDCRM.sign(userList, encX, message);
        
        //print the signature length
        System.out.println("\n\n--Info: the bitlength of r is: " + signature.getR().bitLength());
        System.out.println("--Info: the bitlength of s is: " + signature.getS().bitLength());
        
        
        if(signature != null) {        	
        	//signature verify
            FusionDCRM.verify(signature, message, pk);        	
        }else {
			System.out.println("\n\n@@ERROR@@@@@@@@@@@@@@@@@@@@@@@@@@@@: ECDSA Signature Verify NOT Passed!"+
					"\n That signature is a InValid Siganture!\n\n");
        }
        
        sinput.close();
		
	}
	

}
