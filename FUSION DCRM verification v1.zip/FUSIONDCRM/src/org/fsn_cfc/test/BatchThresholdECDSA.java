package org.fsn_cfc.test;

import java.math.BigInteger;
import java.util.List;

import org.bouncycastle.math.ec.ECPoint;
import org.fsn_cfc.fusiondcrm.FusionDCRM;
import org.fsn_cfc.util.ECDSASignature;
import org.fsn_cfc.util.User;

public class BatchThresholdECDSA {

	public static void main(String[] args) {
		
		
		
		/*
		 * 
		 * run ThresholdECDSA 20 times
		 * 
		 */
		int BatchCount = 20;
		
		String message = "hello FSN";
		int userCount = 4;
		
		for(int iterate=1 ; iterate<=BatchCount ; iterate++) {

			long start = System.currentTimeMillis(); 
			
			//key generate
	        List<User> userList = FusionDCRM.keyGenerate(userCount);
	        
	        //Encrypted Private Key
	        BigInteger encX = FusionDCRM.calculateEncPrivateKey(userList);
	        
	        //public key
	        ECPoint pk = FusionDCRM.calculatePubKey(userList);
	        
	        //signature generate
	        ECDSASignature signature = FusionDCRM.sign(userList, encX, message);
	        if(signature != null) {
	        	//signature verify
	            FusionDCRM.verify(signature, message, pk);        	
	        }else {
				System.out.println("\n\n@@ERROR@@@@@@@@@@@@@@@@@@@@@@@@@@@@: ECDSA Signature Verify NOT Passed!"+
						"\n That signature is a InValid Siganture!\n\n");
	        }
			
			long stop = System.currentTimeMillis();
			
	        System.out.println("Current Count is "+iterate+" with running time:"+ (stop - start) +"\n\n\n\n\n\n\n\n\n");
		}
		
	}
	

}
